package Database;

import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.Statement;

public class Database {
	private static final String url = "jdbc:mysql://localhost:3306/";
	private static final String database_name = "users";
	private static final String username = "root";
	private static final String password = "";
	
	private static Connection conn = null;
	private static Statement st = null;
	
	public Database() {
		// TODO Auto-generated constructor stub
	}
	
	public void createDatabase() {
		try {
			conn = DriverManager.getConnection(url, username, password);
			st = conn.createStatement();
			
			String createDatabase = "CREATE DATABASE IF NOT EXISTS " + database_name;
			st.executeUpdate(createDatabase);
			System.out.println("Database created successfully!");
		} catch(SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(st != null)
				st.close();
				if(conn != null)
				conn.close();
			} catch(SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public void createTable() {
		try {
			String urlWithDatabase = url + database_name;
			conn = DriverManager.getConnection(urlWithDatabase, username, password);
			st = conn.createStatement();
			
			String createTable = "CREATE TABLE IF NOT EXISTS user (" + 
			"ID INT AUTO_INCREMENT PRIMARY KEY," +
			"Name VARCHAR(50) NOT NULL," +
			"Email VARCHAR(100) NOT NULL," +
			"Phone VARCHAR(10) NOT NULL," +
			"Pass VARCHAR(100) NOT NULL)";
			st.executeUpdate(createTable);
			System.out.println("Table 'user' created successfully!");
		}catch(SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(st != null)
				st.close();
				if(conn != null)
				conn.close();
			} catch(SQLException e) {
				e.printStackTrace();
			}
		}
	} 
}
