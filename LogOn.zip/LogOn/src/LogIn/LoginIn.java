package LogIn;

import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Scanner;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class LoginIn {
	private static final String url = "jdbc:mysql://localhost:3306/users";
	private static final String username = "root";
	private static final String password = "";
	
	private static Connection conn = null;
	private static PreparedStatement pst = null;
	private static ResultSet rs = null;
	
	private static Scanner s;
	
	public LoginIn() {
		s = new Scanner(System.in);
	}
	
	public void Login() {
		while(true) {
			try {
				System.out.println("Enter Username or Email or Phone: ");
				String input = s.nextLine();
				System.out.println("Enter Password: ");
				String pass = s.nextLine();
				
				conn = DriverManager.getConnection(url, username, password);
				pst = conn.prepareStatement("SELECT * FROM user WHERE (Name = ? OR Email = ? OR Phone = ?) AND Pass = ?");
				pst.setString(1, input);
				pst.setString(2, input);
				pst.setString(3, input);
				pst.setString(4, pass);
				rs = pst.executeQuery();
				
				if(rs.next()) {
					System.out.println("Login successfully!");
					break;
				}else {
					System.out.println("Incorect Username or Password. Please try again: ");
				}
			} catch(SQLException e) {
				e.printStackTrace();
			} finally {
				try {
					if(rs != null)
					rs.close();
					if(pst != null)
					pst.close();
					if(conn != null)
					conn.close();
				} catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}
		
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LoginIn log = new LoginIn();
		log.Login();
	}

}
