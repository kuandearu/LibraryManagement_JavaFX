package Log;

import Database.Database;

public class MyProgram {

	public MyProgram() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Database data = new Database();
		data.createDatabase();
		data.createTable();
		
		Menu menu = new Menu();
		menu.Running();
	}
}
