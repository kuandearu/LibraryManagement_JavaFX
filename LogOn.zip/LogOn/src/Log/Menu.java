package Log;

public class Menu extends AdAccess {
	
	public Menu() {
		
	}
	
	public void Running() {
		AdAccess access = new AdAccess();
		
		while(true) {
			System.out.println("1. Add User");
			System.out.println("2. Show User");
			System.out.println("3. Update User");
			System.out.println("4. Delete User");
			System.out.println("5. Search User");
			System.out.println("6. Exit");
			
			int option = validation(0);
			
			switch(option) {
				case 1:
					access.AddUser();
					break;
				case 2:
					access.ShowUser();
					break;
				case 3:
					access.UpdateUser();
					break;
				case 4:
					access.DeleteUser();
					break;
				case 5:
					access.SearchUser();
					break;
				case 6:
					System.out.println("System closed!");
					access.Close();
					System.exit(0);
				default:
					System.out.println("Invalid choice! Please choose the options below!");
			}
		}
	}
}
