package Log;

import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Scanner;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class AdAccess extends Person {
	private static final String url = "jdbc:mysql://localhost:3306/users";
	private static final String username = "root";
	private static final String password = "";
	
	private static Connection conn = null;
	private static PreparedStatement pst = null;
	private static ResultSet rs = null;
	
	private static Scanner s;
	
	public AdAccess() {
		s = new Scanner(System.in);
	}
	
	public AdAccess(int id, String name, String email, String phone, String pass) {
		super(id, name, email, phone, pass);
	}
	
	public void AddUser() {
		try {
			System.out.println("Enter Name: ");
			name = s.nextLine();
			System.out.println("Enter Email: ");
			email = s.nextLine();
			System.out.println("Enter Phone: ");
			phone = s.nextLine();
			System.out.println("Enter Password: ");
			pass = s.nextLine();
			
			conn = DriverManager.getConnection(url, username, password);
			pst = conn.prepareStatement("INSERT INTO user(Name, Email, Phone, Pass) VALUES(?,?,?,?)");
			pst.setString(1, name);
			pst.setString(2, email);
			pst.setString(3, phone);
			pst.setString(4, pass);
			pst.executeUpdate();
			System.out.println("Added User successfully!");
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void ShowUser() {
		try {
			conn = DriverManager.getConnection(url, username, password);
			pst = conn.prepareStatement("SELECT * FROM user");
			rs = pst.executeQuery();
			
			while(rs.next()) {
				id = rs.getInt("ID");
				name = rs.getString("Name");
				email = rs.getString("Email");
				phone = rs.getString("Phone");
				pass = rs.getString("Pass");
				
				System.out.println(toString());
			}
		} catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void UpdateUser() {
		try {
			System.out.println("Enter UserId for updating: ");
			id = validation(0);
			conn = DriverManager.getConnection(url, username, password);
			pst = conn.prepareStatement("SELECT * FROM user WHERE ID = ?");
			pst.setInt(1, id);
			rs = pst.executeQuery();
			
			if(rs.next()) {
				System.out.println("Enter New Name: ");
				name = s.nextLine();
				System.out.println("Enter New Email: ");
				email = s.nextLine();
				System.out.println("Enter New Phone: ");
				phone = s.nextLine();
				System.out.println("Enter New Password: ");
				pass = s.nextLine();
				
				pst = conn.prepareStatement("UPDATE user SET Name = ?, Email = ?, Phone = ?, Pass = ?");
				pst.setString(1, name);
				pst.setString(2, email);
				pst.setString(3, phone);
				pst.setString(4, pass);
				pst.executeUpdate();
				System.out.println("Update User successfully!");
			} else {
				System.out.println("No ID found!");
			}
		} catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void DeleteUser() {
		try {
			System.out.println("Enter UserId for deleting: ");
			id = validation(0);
			conn = DriverManager.getConnection(url, username, password);
			pst = conn.prepareStatement("SELECT * FROM user WHERE ID = ?");
			pst.setInt(1, id);
			rs = pst.executeQuery();
			
			if(rs.next()) {
				pst = conn.prepareStatement("DELETE FROM user");
				pst.executeUpdate();
				System.out.println("Delete User successfully!");
			} else {
				System.out.println("No ID found!");
			}
		} catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void SearchUser() {
		try {
			System.out.println("Enter Name or Email or Phone for Searching: ");
			String search = s.nextLine();
			conn = DriverManager.getConnection(url, username, password);
			pst = conn.prepareStatement("SELECT * FROM user WHERE Name = ? OR Email = ? OR Phone = ?");
			pst.setString(1, search);
			pst.setString(2, search);
			pst.setString(3, search);
			rs = pst.executeQuery();
			
			if(rs.next()) {
				System.out.println("Here's the Information of Users you're looking for");
				do {
					id = rs.getInt("ID");
					name = rs.getString("Name");
					email = rs.getString("Email");
					phone = rs.getString("Phone");
					pass = rs.getString("Pass");
					
					System.out.println(toString());
				} while(rs.next());
			} else {
				System.out.println("No User Found!");
			}
		} catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public int validation(int validate) {
		while(true) {
			try {
				validate = Integer.parseInt(s.nextLine());
				return validate;
			}catch(NumberFormatException e) {
				System.out.println("Invalid input! You must enter numbers only: ");
			}
		}
	}

	@Override
	public String validPhone(String phoneInput) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return  "ID: " + id +
				"\nUsername: " + name +
				"\nEmail: " + email +
				"\nPhone: " + phone +
				"\nPassword: " + pass;
	}

	@Override
	public void Close() {
		// TODO Auto-generated method stub
		try {
			if(rs != null)
			rs.close();
			if(pst != null)
			pst.close();
			if(conn != null)
			conn.close();
		} catch(SQLException e) {
			e.printStackTrace();
		}
	} 
}
